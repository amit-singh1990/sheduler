/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import models.Appointment;
import models.AppointmentDB;
import models.Customer;



public class AppointmentMainController implements Initializable {

    
    @FXML
    private AnchorPane appointmentMain;
    
    @FXML
    private TableView<Customer> customerTable;
    
    @FXML 
    private TableColumn<Customer, Integer> customerId;
    
    @FXML
    private TableColumn<Customer, String> customerName;
    
    @FXML
    private Label monthCustomerLabel;
    
    @FXML
    private TableView<Appointment> monthAptTable;
    
    @FXML
    private TableColumn<Appointment, String> monthDescription;
    
    @FXML
    private TableColumn<Appointment, String> monthContact;
    
    @FXML
    private TableColumn<Appointment, String> monthLocation;
    
    @FXML
    private TableColumn<Appointment, String> monthStart;
    
    @FXML
    private TableColumn<Appointment, String> monthEnd;
    
    @FXML
    private Label weekCustomerLabel;
    
    @FXML
    private TableView<Appointment> weekAptTable;
    
    @FXML
    private TableColumn<Appointment, String> weekDescription;
    
    @FXML
    private TableColumn<Appointment, String> weekContact;
    
    @FXML
    private TableColumn<Appointment, String> weekLocation;
    
    @FXML
    private TableColumn<Appointment, String> weekStart;
    
    @FXML
    private TableColumn<Appointment, String> weekEnd;
    
    @FXML
    private Tab monthly;
    
    private Customer selectedCustomer;
    
    private Appointment selectedAppointment;
    
    private boolean isMonthly;
      
    
    
    @FXML
    public void handleCustomerClick(MouseEvent event) {
         selectedCustomer = customerTable.getSelectionModel().getSelectedItem();
        int id = selectedCustomer.getCustomerId();
        monthCustomerLabel.setText(selectedCustomer.getCustomerName());
        weekCustomerLabel.setText(selectedCustomer.getCustomerName());       
        monthAptTable.setItems(AppointmentDB.getMonthlyAppointments(id));
        weekAptTable.setItems(AppointmentDB.getWeeklyAppoinments(id));
        
    }   
    
    // Two Lambda expressions are used on handleAddButton to make it more efficient and readability.
    
    @FXML 
    public void handleAddButton() {
        if(customerTable.getSelectionModel().getSelectedItem() != null) {
            selectedCustomer = customerTable.getSelectionModel().getSelectedItem();
        } else {
            return;
        }
        Dialog<ButtonType> dialog = new Dialog();
        dialog.initOwner(appointmentMain.getScene().getWindow());
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("AppointmentAdd.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch(IOException e) {
            System.out.println("AppointmentAdd Error: " + e.getMessage());
        }
        ButtonType save = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(save);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        AppointmentAddController controller = fxmlLoader.getController();
        controller.populateCustomerName(selectedCustomer.getCustomerName());
        controller.determineContact(selectedCustomer);
        dialog.showAndWait().ifPresent((response -> {
            if(response == save) {
                if(controller.handleAddAppointment(selectedCustomer.getCustomerId())) {
                    monthAptTable.setItems(AppointmentDB.getMonthlyAppointments(selectedCustomer.getCustomerId()));
                    weekAptTable.setItems(AppointmentDB.getWeeklyAppoinments(selectedCustomer.getCustomerId()));                    
                
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Add Appointment Error");
                    alert.setContentText(controller.displayErrors());
                    alert.showAndWait().ifPresent((response2 -> {
                        if(response2 == ButtonType.OK) {
                            handleAddButton();
                        }
                    }));
                }
            }
        }));
    }
    
    
   // Two Lambda expressions are used on handleModifyButton to make it more efficient and readability.
    @FXML
    public void handleModifyButton() {
        if(monthly.isSelected()) {
            if(monthAptTable.getSelectionModel().getSelectedItem() != null) {
                selectedAppointment = monthAptTable.getSelectionModel().getSelectedItem();
            }
            else {
                return;
            }
        }
             else {   
                 if (weekAptTable.getSelectionModel().getSelectedItem() != null) {
                selectedAppointment = weekAptTable.getSelectionModel().getSelectedItem();                               
            }               
            else {
                return;
            }       
               
                 }
               
        Dialog<ButtonType> dialog = new Dialog();
        dialog.initOwner(appointmentMain.getScene().getWindow());
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("AppointmentModify.fxml"));
        try {
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch(IOException e) {
            System.out.println("AppointmentModify Error: " + e.getMessage());
        }
        ButtonType save = new ButtonType("Save", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(save);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        AppointmentModifyController controller = fxmlLoader.getController();
        controller.populateFields(selectedCustomer, selectedAppointment);
        dialog.showAndWait().ifPresent((response -> {
            if(response == save) {
                if(controller.handleModifyAppointment(selectedAppointment.getAptId())) {
                    monthAptTable.setItems(AppointmentDB.getMonthlyAppointments(selectedCustomer.getCustomerId()));
                    weekAptTable.setItems(AppointmentDB.getWeeklyAppoinments(selectedCustomer.getCustomerId()));                              
                     
                } else {                   
                    
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Modify Appointment Error");
                    alert.setContentText(controller.displayErrors());
                    alert.showAndWait().ifPresent((response2 -> {
                        if(response2 == ButtonType.OK) {
                            handleModifyButton();
                        }
                    }));
                }
            }
        }));}   
    
    
    @FXML
    public void handleBackButton(ActionEvent event) {
        ((Node)(event.getSource())).getScene().getWindow().hide();   }    
    
    
    
     // Lambda expression is used on handleDeleteButton to make it efficency and readability.
    @FXML
    public void handleDeleteButton() {
        if(monthly.isSelected()) {
            isMonthly = true;
            if(monthAptTable.getSelectionModel().getSelectedItem() != null) {
                selectedAppointment = monthAptTable.getSelectionModel().getSelectedItem();
            } else {
                return;
            }
        }
        else {
            isMonthly = false;
            if(weekAptTable.getSelectionModel().getSelectedItem() != null) {
                selectedAppointment = weekAptTable.getSelectionModel().getSelectedItem();                
                
            } else {
                return;
            }       
            
        }        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete");
        alert.setHeaderText("Delete Appointment Record");
        alert.setContentText("Delete Appointment?");
        alert.showAndWait().ifPresent((response -> {
            if(response == ButtonType.OK) {
                AppointmentDB.deleteAppointment(selectedAppointment.getAptId());
                if(isMonthly) {
                   monthAptTable.setItems(AppointmentDB.getMonthlyAppointments(selectedCustomer.getCustomerId()));                    
                    
                   
                } else {
                    weekAptTable.setItems(AppointmentDB.getWeeklyAppoinments(selectedCustomer.getCustomerId()));                    
                    
                }
                
            }
        }));
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        customerId.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        customerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        customerTable.setItems(CustomerMainController.getAllCustomers());
        
        // Lambda expression is used to imporve efficency
        monthDescription.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptDescriptionProperty();
        });
         // Lambda expression is used to imporve efficency
        monthContact.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptContactProperty();
        });
         // Lambda expression is used to imporve efficency
        monthLocation.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptLocationProperty();
        });
         // Lambda expression is used to imporve efficency
        monthStart.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptStartProperty();
        });
        // Lambda expression is used to imporve efficency
        monthEnd.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptEndProperty();
        });
        // Lambda expression is used to imporve efficency
        weekDescription.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptDescriptionProperty();
        });
        // Lambda expression is used to imporve efficency
        weekContact.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptContactProperty();
        });
        // Lambda expression is used to imporve efficency
        weekLocation.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptLocationProperty();
        });
        // Lambda expression is used to imporve efficency
        weekStart.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptStartProperty();
        });
        // Lambda expression is used to imporve efficency
        weekEnd.setCellValueFactory(cellData -> {
            return cellData.getValue().getAptEndProperty();
        });
                       
    }     
    
}
